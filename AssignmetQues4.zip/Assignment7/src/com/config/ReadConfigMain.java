package com.config;

import java.io.IOException;

public class ReadConfigMain {

	public static void main(String[] args) throws IOException {
		
		ReadConfig properties=new ReadConfig();
		properties.getPropValues();

	}

}
