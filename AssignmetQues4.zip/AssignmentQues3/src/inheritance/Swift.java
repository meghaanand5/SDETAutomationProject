package inheritance;

public class Swift extends NewCar {

	public Swift(){
		System.out.println("We are in Swift constructor");
	}

	public void start(){
		System.out.println("We are in Swift start");
	}
	
	public void stop(){
		System.out.println("We are in Swift stop");
	}
	
	public void theftsafety(){
		System.out.println("We are in Swift Theftsafety");
	}
	
	
}
